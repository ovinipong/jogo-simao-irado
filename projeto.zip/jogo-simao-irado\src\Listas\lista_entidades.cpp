#include "lista_entidades.hpp"

using namespace listas;

ListaEntidades :: ListaEntidades() : LEs()
{
    
}

ListaEntidades :: ~ListaEntidades()
{
    
}

void ListaEntidades :: incluir(Entidade* pE)
{
    LEs.incluir(pE);  
}

void ListaEntidades :: percorrer()
{
    auto aux = LEs.getPrimeiro();
    while (aux != NULL)
    {
        if (aux->pInfo != NULL)
        {
            aux->pInfo->executar();
        }
        auto aux2 = aux->getProx();//arrumar lista
        if(aux->pInfo->getValido()==false)
        {
            LEs.remover(aux->pInfo);
        }
        aux=aux2;
    }
}

void ListaEntidades :: percorrer_desenhar()
{
    auto aux = LEs.getPrimeiro();
    
    while (aux != NULL)
    {
        if (aux->pInfo != NULL)
        {
            aux->pInfo->desenhar();
        }
        aux = aux->getProx();
    }
}

void ListaEntidades :: remover(Entidade* pE)
{
    LEs.remover(pE);
}

void ListaEntidades :: limpar()
{
    LEs.limpar();
}