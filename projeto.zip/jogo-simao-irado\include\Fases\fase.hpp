#pragma once

#include "lista_entidades.hpp"
#include "gerenciador_colisoes.hpp"
#include "ente.hpp"
#include "bolinho.hpp"
#include "plataforma.hpp"
#include "bloco.hpp"
#include "jogador.hpp"
#include "agua.hpp"
#include "bolo.hpp"
#include "projetil.hpp"
#include "lustre.hpp"
#include "rato.hpp"

#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <random>

using namespace entidades;
using namespace listas;
using namespace gerenciadores;

//class PrimeiraFase;

namespace fases {

class Fase : public Ente
{
    protected:
        ListaEntidades lista_ents;
        GerenciadorColisoes gc;
        std::ifstream arquivo;
        int minimo_ent;
        int maxInimFaceis;
        int maxPlataformas;
        float mapa_largura;
        float mapa_altura;
        Jogador* pJogador1;
        Jogador* pJogador2;
        std::vector<Projetil*> projeteis_jogador;
        std::vector<Projetil*> projeteis_rato;
        bool concluida;
        sf::Clock clock;//para ajustes de gravidade;

    public:
        Fase(const std::string& caminhoMapa="", Jogador* pJog1=NULL, Jogador* pJog2=NULL);
        ~Fase();
        void executar();
        bool getConcluida() { return concluida; }
        void salvarEntidades() { lista_ents.percorrerSalvar(); }
        void carregarFase();
        
    protected:
        void move_camera();

        void criarInimBolinhos();
        void criarPlataformas();
        virtual void criarInimigos()=0;
        virtual void criarObstaculos()=0;
        virtual void criarCenario(const std::string& caminhoFundo);
        void criarProjeteisJogador();
        void ajustarProjeteisJogador();
};

}