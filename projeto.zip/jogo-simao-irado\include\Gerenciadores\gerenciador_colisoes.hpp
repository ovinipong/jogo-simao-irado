#pragma once

#include <list>
#include <vector>
#include <set>

#include "inimigo.hpp"
#include "jogador.hpp"
#include "entidade.hpp"
#include "obstaculo.hpp"
#include "bloco.hpp"
#include "projetil.hpp"

using namespace std;
using namespace entidades;

namespace gerenciadores{

class GerenciadorColisoes
{
    private:
        vector <Inimigo*> inimigos;
        list <Obstaculo*> obstaculos;
        set <Projetil*> projeteis;
        vector <Bloco*> blocos;
        vector <Jogador*> jogadores;
    private:
        const bool verificarColisao(Entidade *pe1, Entidade *pe2);
        void tratarColisoesJogObst();
        void tratarColisoesJogInim();
        void tratarColisoesJogProj();
        void tratarColisoesInimProj();
        void tratarColisoesInimObst();
        void tratarColisioesJogBloco();
        void tratarColisoesInimBloco();
        void tratarColisoesObstBloco();

    public:
        GerenciadorColisoes();
        ~GerenciadorColisoes();
        void incluirInimigo(Inimigo *pi);
        void incluirJogadores(Jogador *pj);
        void incluirObstaculo(Obstaculo *po);
        void incluirBloco(Bloco *pb);
        void incluirProjetil(Projetil *pp);
        void executar();
};

}